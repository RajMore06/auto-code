/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "math.h"
#include "stdio.h"
#include "stdlib.h"
#include "stdbool.h"
#include "FreeRTOS.h"
#include "task.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define DMA_RX_BUFFER_SIZE 1
#define CIRC_BUFFER_SIZE   32
#define UART_LINE_SIZE     6
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
int head_c = 0, spd = 0, rpm = 0;
uint32_t TxMailbox;
uint8_t TxData[8];
uint8_t txData[1];
CAN_TxHeaderTypeDef TxHeader;
uint8_t DMA_RxBuffer[DMA_RX_BUFFER_SIZE];
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;

/* Definitions for uartRxTask */
osThreadId_t uartRxTaskHandle;
const osThreadAttr_t uartRxTask_attributes = {
  .name = "uartRxTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};
/* Definitions for pidTask */
osThreadId_t pidTaskHandle;
const osThreadAttr_t pidTask_attributes = {
  .name = "pidTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* USER CODE BEGIN PV */
typedef struct {
  uint8_t circ_buffer[CIRC_BUFFER_SIZE];
  volatile uint16_t circWriteIndex;
  volatile uint16_t circReadIndex;
} circular_buff;
circular_buff C_buffer;

static volatile uint32_t g_latestSetpoint = 106;
static volatile uint32_t g_latestFeedback = 0;
//static volatile uint8_t s_canTimeoutCount = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_CAN_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
void StartDefaultTask(void *argument);
void StartTask02(void *argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int Constrain(int au32_IN, int au32_MIN, int au32_MAX);
static inline float ConstrainFloat(float value, float minVal, float maxVal);
int MAP(int au32_IN, int au32_INmin, int au32_INmax, int au32_OUTmin,int au32_OUTmax);
static inline float MapFloat(float x, float in_min, float in_max, float out_min, float out_max);
double cantoWheelAngle(int x);
double steerHead(double vel, double angle_in, double delta_t);
double degtorad(double deg);
double radtodeg(double rd);
double headNormal(double err_val);
void Init_PWM(void);
void SerialWrite(char *uart2Data);
void UART_SendInt(int value);
void UART_SendFloat(float value);
void CAN_TX(uint8_t val);
void can_transmitSingleByte(uint8_t Txid, uint8_t Txdata);
void canInit_recieveMultiID(void);
void CanPid(int setpoint, int feedback, float kp, float ki, float kd);
void init_circ_buffer(circular_buff *C);
void push_data(circular_buff *C, uint8_t Rcv_data);
bool pop_data(circular_buff *C, uint8_t *data);
void UART_Parse_Setpoint(circular_buff *C);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_CAN_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_Base_Start(&htim2);
  canInit_recieveMultiID();
  init_circ_buffer(&C_buffer);
  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of uartRxTask */
  uartRxTaskHandle = osThreadNew(StartDefaultTask, NULL, &uartRxTask_attributes);

  /* creation of pidTask */
  pidTaskHandle = osThreadNew(StartTask02, NULL, &pidTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
  HAL_UARTEx_ReceiveToIdle_DMA(&huart2, DMA_RxBuffer, DMA_RX_BUFFER_SIZE);
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN;
  hcan.Init.Prescaler = 8;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_7TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_8TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */

  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4096;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PB3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void init_circ_buffer(circular_buff *C) {
  C->circWriteIndex = 0;
  C->circReadIndex  = 0;
}

void push_data(circular_buff *C, uint8_t Rcv_data) {
  uint16_t nextWrite = (C->circWriteIndex + 1) % CIRC_BUFFER_SIZE;
  C->circ_buffer[C->circWriteIndex] = Rcv_data;

  if (nextWrite == C->circReadIndex) {
    UBaseType_t uxSaved = taskENTER_CRITICAL_FROM_ISR();
    C->circReadIndex = (C->circReadIndex + 1) % CIRC_BUFFER_SIZE;
    taskEXIT_CRITICAL_FROM_ISR(uxSaved);
  }
  C->circWriteIndex = nextWrite;
}

bool pop_data(circular_buff *C, uint8_t *data) {
  bool got;
  taskENTER_CRITICAL();
  if (C->circWriteIndex == C->circReadIndex) {
    got = false;
  } else {
    *data = C->circ_buffer[C->circReadIndex];
    C->circReadIndex = (C->circReadIndex + 1) % CIRC_BUFFER_SIZE;
    got = true;
  }
  taskEXIT_CRITICAL();
  return got;
}

static uint16_t s_uartOldPos = 0;

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size) {
  if (huart->Instance == USART2) {
    uint16_t pos = Size;
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    if (pos != s_uartOldPos) {
      if (pos > s_uartOldPos) {
        for (uint16_t i = s_uartOldPos; i < pos; i++)
          push_data(&C_buffer, DMA_RxBuffer[i]);
      }
      else {
        for (uint16_t i = s_uartOldPos; i < DMA_RX_BUFFER_SIZE; i++)
          push_data(&C_buffer, DMA_RxBuffer[i]);
        for (uint16_t i = 0; i < pos; i++)
          push_data(&C_buffer, DMA_RxBuffer[i]);
      }
      s_uartOldPos = pos;
      vTaskNotifyGiveFromISR((TaskHandle_t)uartRxTaskHandle, &xHigherPriorityTaskWoken);
    }
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
  }
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
  CAN_RxHeaderTypeDef rxHeader;
  uint8_t rxData[8];
  BaseType_t xHigherPriorityTaskWoken = pdFALSE;
  while (HAL_CAN_GetRxFifoFillLevel(hcan, CAN_RX_FIFO0) > 0) {
    if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxHeader, rxData) == HAL_OK) {
    	if(rxHeader.StdId == 0x12) {
    		int16_t fb = (int16_t)((rxData[0]));
    		g_latestFeedback = (int32_t)fb;
    		vTaskNotifyGiveFromISR((TaskHandle_t)pidTaskHandle, &xHigherPriorityTaskWoken);
    	}
    	if(rxHeader.StdId == 0x691) {
			head_c = (rxData[0] | (rxData[1] << 8));
    	}
    	if(rxHeader.StdId == 0x104) {
    		spd = ((rxData[0] << 8) | rxData[1]);
    	}
    	if(rxHeader.StdId == 0x103) {
    		rpm = ((rxData[0] << 8) | rxData[1]);
    	}
    }
  }
  portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void UART_Parse_Setpoint(circular_buff *C) {
  static char line[UART_LINE_SIZE];
  static uint8_t idx = 0;
  static uint8_t gotCR = 0;
  uint8_t ch;
  while (pop_data(C, &ch)) {
    if (ch >= '0' && ch <= '9') {
      if (idx < UART_LINE_SIZE - 1) {
        line[idx++] = ch;
      }
      else {
        idx = 0;
        gotCR = 0;
      }
    }
    else if (ch == '\r') {
      gotCR = 1;
    }
    else if (ch == '\n' && gotCR) {
      line[idx] = '\0';
      g_latestSetpoint = (int32_t)atoi(line);
      idx = 0;
      gotCR = 0;
    }
    else {
      idx = 0;
      gotCR = 0;
    }
  }
}

void CanPid(int setpoint, int feedback, float kp, float ki, float kd) {
	char temp[64];
	uint32_t start_t;
	static uint32_t final_t = 0;
	float elapsedTime, error;
	static float prev_error = 0.0f;
	static float integral = 0.0f;
	float derivative;
	float PIDCAN_value = 0.0f;
	start_t = HAL_GetTick();
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4) == 1) {
		can_transmitSingleByte(0x01, 1);
		//integral = 0;
		//prev_error = 0;
	}
	else {
		can_transmitSingleByte(0x01, 0);
	}
	HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
	elapsedTime = ((float)(start_t - final_t))/1000;
	error = (float) (setpoint - feedback);
	if(elapsedTime <= 0.0f) elapsedTime = 0.001f;
	integral += (error * elapsedTime);
	if(integral >= 10000.0f) integral = 10000.0f;
	if(integral <= -10000.0f) integral = -10000.0f;
	derivative = (float) (error - prev_error) / elapsedTime;
	PIDCAN_value = (kp * error + ki * integral + kd * derivative);
	float dutyCANCycle = ConstrainFloat(PIDCAN_value, -4096.0f, 4096.0f);
	prev_error = error;
	final_t = start_t;
	int values = MapFloat(dutyCANCycle, -4096.0f, 4096.0f, 0.0f, 4096.0f);
	TIM2->CCR1 = values;
	//int len = snprintf(temp,sizeof(temp),"%d, %d, %.2f, %.2f, %.2f\r\n", setpoint, feedback,(float) head_c * 0.01f, (float) rpm * 0.5f, (float) spd * 0.01f);
	//HAL_UART_Transmit(&huart2, (uint8_t*)temp, len, HAL_MAX_DELAY);
}

int Constrain(int au32_IN, int au32_MIN, int au32_MAX) {
  if (au32_IN < au32_MIN) {
    return au32_MIN;
  } else if (au32_IN > au32_MAX) {
    return au32_MAX;
  } else {
    return au32_IN;
  }
}

static inline float ConstrainFloat(float value, float minVal, float maxVal){
	if(value > maxVal) return maxVal;
	if(value < minVal) return minVal;
	return value;
}

int MAP(int au32_IN, int au32_INmin, int au32_INmax, int au32_OUTmin, int au32_OUTmax) {
  return ((((au32_IN - au32_INmin) * (au32_OUTmax - au32_OUTmin))
      / (au32_INmax - au32_INmin)) + au32_OUTmin);
}

static inline float MapFloat(float x, float in_min, float in_max, float out_min, float out_max){
    return ((x - in_min) *(out_max - out_min) /(in_max - in_min))+ out_min;
}

double cantoWheelAngle(int x) {
  double ang = (0.0006*x*x) + (0.3948*x) - 48.4053;
  return ang;
}

double steerHead(double vel, double angle_in, double delta_t) {
  double tang = tan(degtorad(angle_in));
  double rad = (2.264 / tang) - 1.45 / 2;
  double omega = vel / rad;
  double theta = radtodeg((omega*delta_t));
  return theta;
}

double degtorad(double deg){
  return (deg * (M_PI / 180.0));
}

double radtodeg(double rd){
  return (rd * (180.0 / M_PI));
}

double headNormal(double err_val) {
  if(err_val < 0.0 && err_val > -360.0) err_val = err_val +360.0;
  else if(err_val > 360.0) err_val = err_val - 360.0;
  return err_val;
}

void Init_PWM(void) {
  int Rcv=0;
  while (Rcv < 4096) {
    TIM2->CCR1 = Rcv;
    Rcv += 10;
    HAL_Delay(10);
  }

  while (Rcv > 0) {
    TIM2->CCR1 = Rcv;
    Rcv -= 10;
    HAL_Delay(10);
  }
}

void SerialWrite(char *uart2Data) {
  HAL_StatusTypeDef uart_status;
  if (huart2.gState == HAL_UART_STATE_READY) {
    uart_status = HAL_UART_Transmit_DMA(&huart2,(uint8_t*)uart2Data,strlen(uart2Data));
    if (uart_status != HAL_OK) {
      HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
    }
  }
}

void UART_SendInt(int value) {
  static char txbuf[32];
  if (huart2.gState == HAL_UART_STATE_READY) {
    int len = snprintf(txbuf, sizeof(txbuf), "%d\r\n", value);
    HAL_UART_Transmit_DMA(&huart2, (uint8_t*)txbuf, len);
  }
}

void UART_SendFloat(float value) {
  static char txbuf[32];
  if (huart2.gState == HAL_UART_STATE_READY) {
    int scaled = (int)(value * 100);
    int len = snprintf(txbuf, sizeof(txbuf), "%d.%02d\r\n",scaled / 100, abs(scaled % 100));
    HAL_UART_Transmit_DMA(&huart2, (uint8_t*)txbuf, len);
  }
}

void CAN_TX(uint8_t val) {
  TxHeader.IDE = CAN_ID_STD;
  TxHeader.StdId = 0x01;
  TxHeader.RTR = CAN_RTR_DATA;
  TxHeader.DLC = 1;
  txData[0]=val;

  if (HAL_CAN_AddTxMessage(&hcan, &TxHeader, txData, &TxMailbox) != HAL_OK) {
    Error_Handler();
  }
}

void can_transmitSingleByte(uint8_t Txid, uint8_t Txdata) {
  /***
  * Single byte data transmit function
  * DLC Value define 2 - 16 bit
  * Single ID transmit CAN ID
  * ID size is restrict to 8 bit size i.e max value = 256
  */
  TxHeader.IDE = CAN_ID_STD;
  TxHeader.StdId = Txid;
  TxHeader.RTR = CAN_RTR_DATA;
  TxHeader.DLC = 1;
  TxData[0] = Txdata;

  if (HAL_CAN_AddTxMessage(&hcan, &TxHeader, TxData, &TxMailbox) != HAL_OK) {
    Error_Handler();
  }
}

void canInit_recieveMultiID(void) {
  CAN_FilterTypeDef canfilterconfig;

  canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
  canfilterconfig.FilterBank = 1;
  canfilterconfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
  canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
  canfilterconfig.FilterIdHigh = 0x1fff;
  canfilterconfig.FilterIdLow = 0xffff;
  canfilterconfig.FilterMaskIdHigh = 0;
  canfilterconfig.FilterMaskIdLow = 0;

  if (HAL_CAN_ConfigFilter(&hcan, &canfilterconfig) != HAL_OK) {
    Error_Handler();
  }

  if (HAL_CAN_Start(&hcan) != HAL_OK) {
    Error_Handler();
  }
}

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the uartRxTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
  for(;;)
  {
	  ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
	  UART_Parse_Setpoint(&C_buffer);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the pidTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void *argument)
{
  /* USER CODE BEGIN StartTask02 */
  /* Infinite loop */
  for(;;)
  {
	  //uint32_t signalled = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(CAN_FEEDBACK_TIMEOUT_MS));
	  ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
	  int32_t setpoint = g_latestSetpoint;
	  int32_t feedback = g_latestFeedback;
//	  if (signalled == 0) {
//	    if (s_canTimeoutCount < 255) s_canTimeoutCount++;
//	  }
//	  float kp_rpm;
//	  kp_rpm = (-0.1837f * rpm) + 554.27f;
//	  CanPid((int)setpoint, (int)feedback, kp_rpm, 0.0005, 0.1);

//	  CanPid((int)setpoint, (int)feedback, 230.0, 0.0005, 0.1); //L3-1200
//	  CanPid((int)setpoint, (int)feedback, 250.0, 0.0005, 0.1); //H1-1000
//	  CanPid((int)setpoint, (int)feedback, 160.0, 0.0005, 0.4); //RTK Last Tuning
	  CanPid((int)setpoint, (int)feedback, 210.0, 0.0005, 0.4); //Cultivator-IMU
  }
  /* USER CODE END StartTask02 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
