/*
 * bno08x.h  —  BNO08x SH2 driver (4-pin I²C, no INT/RST)
 *
 * Target : STM32F303K8T6, HAL, I2C1 @ 100 kHz (PB6=SCL, PB7=SDA)
 * Frame  : Sensor reports quaternion in its own body frame.
 *          BNO08x_GetHeadingDeg() extracts yaw (Z-axis rotation) and
 *          returns it as a compass heading [0, 360°).
 *
 * Design notes
 * ────────────
 *  • All public functions are reentrant with respect to their own arguments;
 *    they share no writable globals between calls.
 *  • No blocking HAL_Delay() inside the driver — callers handle timing.
 *  • rx_buf lives in the .c translation unit; callers never touch it.
 */

#ifndef BNO08X_H
#define BNO08X_H

#include "stm32f3xx_hal.h"
#include <stdint.h>
#include <stdbool.h>
#include <math.h>           /* atan2f, required by BNO08x_GetHeadingDeg */

/* ── I²C configuration ───────────────────────────────────────────────────── */

extern I2C_HandleTypeDef hi2c1;
#define BNO_I2C             hi2c1

/*
 * 7-bit address shifted left by 1 for HAL (which expects 8-bit write addr).
 *   SA0 pin LOW  → 7-bit addr 0x4A → HAL addr 0x94
 *   SA0 pin HIGH → 7-bit addr 0x4B → HAL addr 0x96
 * Default below assumes SA0 = HIGH (common on breakout boards).
 * Change to (0x4A << 1) if SA0 is tied to GND.
 */
#define BNO_I2C_ADDR        ((uint16_t)(0x4B << 1))   /* SA0=VCC  */
#define BNO_I2C_TIMEOUT_MS  ((uint32_t)50U)

/* ── SHTP channel IDs (SH2 ref §1.3.1) ──────────────────────────────────── */

#define SHTP_CH_COMMAND     ((uint8_t)0U)
#define SHTP_CH_EXECUTABLE  ((uint8_t)1U)
#define SHTP_CH_CONTROL     ((uint8_t)2U)
#define SHTP_CH_REPORTS     ((uint8_t)3U)
#define SHTP_CH_MAX         ((uint8_t)6U)   /* total channels in SHTP spec */

/* ── SH2 report / command IDs (SH2 ref §6) ──────────────────────────────── */

#define SH2_GET_PRODUCT_ID  ((uint8_t)0xF9U)
#define SH2_PRODUCT_ID_RESP ((uint8_t)0xF8U)
#define SH2_SET_FEATURE_CMD ((uint8_t)0xFDU)
#define SH2_ROTATION_VECTOR ((uint8_t)0x05U)
#define EXEC_SOFT_RESET     ((uint8_t)0x01U)

/* ── SHTP timestamp sub-record IDs ──────────────────────────────────────── */

#define SHTP_RID_BASE_TS    ((uint8_t)0xFBU)  /* base timestamp ref  — 5 B */
#define SHTP_RID_TS_REBASE  ((uint8_t)0xFCU)  /* timestamp rebase    — 4 B */

/* ── Fixed-point scale factors (SH2 ref §A.1) ───────────────────────────── */

#define SCALE_Q14   (1.0f / 16384.0f)   /* quaternion components  (Q14) */
#define SCALE_Q12   (1.0f /  4096.0f)   /* accuracy estimate, rad (Q12) */

/* ── Packet buffer size ──────────────────────────────────────────────────── */

/*
 * The largest packet we ever need:
 *   Product ID response  ≈ 20 bytes
 *   Rotation vector      = 4 (hdr) + 5 (base-ts) + 14 (rot-vec) = 23 bytes
 * 64 bytes gives comfortable headroom.
 */
#define BNO_RX_BUF_SIZE     ((uint16_t)64U)

/* ── Sensor record sizes (bytes, inclusive of report-ID byte) ────────────── */

#define SHTP_BASE_TS_LEN    ((uint8_t)5U)   /* 0xFB record */
#define SHTP_TS_REBASE_LEN  ((uint8_t)4U)   /* 0xFC record */
#define SHTP_ROT_VEC_LEN    ((uint8_t)14U)  /* 0x05 record */

/* ── Data structures ─────────────────────────────────────────────────────── */

/**
 * @brief  Rotation vector (unit quaternion) from BNO08x.
 *
 * Components follow the sensor's body frame.
 * Call BNO08x_GetHeadingDeg() to extract a compass heading.
 */
typedef struct {
    float i;            /**< Quaternion X component                    */
    float j;            /**< Quaternion Y component                    */
    float k;            /**< Quaternion Z component                    */
    float real;         /**< Quaternion W (scalar) component           */
    float accuracy_rad; /**< Estimated heading accuracy [radians]      */
    bool  valid;        /**< true when fields above hold fresh data    */
} BNO08x_RotVec_t;

/**
 * @brief  Product / firmware identification from BNO08x.
 */
typedef struct {
    uint8_t  sw_major;    /**< Firmware major version                  */
    uint8_t  sw_minor;    /**< Firmware minor version                  */
    uint16_t sw_patch;    /**< Firmware patch version                  */
    uint32_t sw_build;    /**< Firmware build number                   */
    uint16_t part_number; /**< Silicon part number                     */
    bool     valid;       /**< true when fields above are populated    */
} BNO08x_ProductID_t;

/* ── Public API ──────────────────────────────────────────────────────────── */

/**
 * @brief  Scan the I²C bus and list responding device addresses.
 * @param[out] out     Caller-allocated buffer for comma-separated hex strings.
 * @param[in]  bufsz   Size of @p out in bytes (≥ 1).
 */
void i2c_bus_scan(char *out, size_t bufsz);

/**
 * @brief  Initialise the BNO08x (power-on reset + soft reset sequence).
 *
 * Must be called once before any other BNO08x function.
 * Contains blocking delays; total worst-case ≈ 860 ms.
 *
 * @return HAL_OK on success, HAL_ERROR on I²C failure.
 */
HAL_StatusTypeDef BNO08x_Init(void);

/**
 * @brief  Read the BNO08x firmware / product ID.
 * @param[out] pid  Destination struct; pid->valid set true on success.
 * @return HAL_OK on success, HAL_ERROR if no valid response received.
 */
HAL_StatusTypeDef BNO08x_GetProductID(BNO08x_ProductID_t *pid);

/**
 * @brief  Enable the Rotation Vector report at the requested rate.
 * @param[in] interval_us  Report interval in microseconds (e.g. 10000 = 100 Hz).
 * @return HAL_OK on success.
 */
HAL_StatusTypeDef BNO08x_EnableRotVec(uint32_t interval_us);

/**
 * @brief  Read one SHTP packet; populate *out if it contains a rotation vector.
 *
 * Returns HAL_OK even when the packet is not a rotation vector report;
 * in that case out->valid is false.  Returns HAL_ERROR only on I²C failure.
 *
 * @param[out] out  Destination struct; check out->valid after return.
 * @return HAL_OK or HAL_ERROR.
 */
HAL_StatusTypeDef BNO08x_ReadPacket(BNO08x_RotVec_t *out);

/**
 * @brief  Extract compass heading (yaw) from a rotation vector quaternion.
 *
 * Uses the standard ZYX Euler yaw formula:
 *   yaw = atan2( 2(W·Z + X·Y),  1 − 2(Y² + Z²) )
 *
 * Valid only when q->valid == true.
 *
 * @param[in] q  Pointer to a valid BNO08x_RotVec_t.
 * @return Heading in degrees [0, 360).
 */
static inline float BNO08x_GetHeadingDeg(const BNO08x_RotVec_t *q)
{
    /*
     * ZYX Euler yaw (rotation about the sensor Z-axis).
     * For compass heading: mount BNO08x with Z pointing up.
     *
     * atan2f range: (−π, π] → shift negative values by 2π to get [0, 360°).
     */
    float yaw = atan2f(
        2.0f * (q->real * q->k + q->i * q->j),
        1.0f - 2.0f * (q->j * q->j + q->k * q->k)
    );

    yaw *= 57.29578f;                  /* rad → deg  (180/π, full precision) */
    if (yaw < 0.0f) yaw += 360.0f;
    return yaw;
}

#endif /* BNO08X_H */
