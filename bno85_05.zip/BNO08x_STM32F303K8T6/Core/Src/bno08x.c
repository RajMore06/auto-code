/*
 * bno08x.c  —  BNO08x SH2 driver (4-pin I²C, no INT/RST)
 *
 * Key improvements over the original
 * ────────────────────────────────────
 *  1. Single I²C transaction per packet (original read_packet() issued TWO
 *     HAL_I2C_Master_Receive() calls; the second fetch pulled the *next*
 *     packet off the sensor's queue, silently discarding the first payload).
 *
 *  2. All blocking HAL_Delay() calls removed from driver internals.
 *     Callers in main.c supply any required inter-call delays, making the
 *     driver safe to use in an RTOS or cooperative-scheduler context.
 *
 *  3. rx_buf is local to read_packet() → functions are reentrant with
 *     respect to their own arguments (no shared writable globals).
 *
 *  4. Fixed off-by-one in bounds check:
 *     original: offset + 14 > total   (wrong — 14-byte record occupies
 *                                       indices [offset … offset+13])
 *     fixed:    offset + SHTP_ROT_VEC_LEN > total
 *               i.e. last valid byte is at offset + SHTP_ROT_VEC_LEN - 1.
 *
 *  5. Fixed signed-shift UB in sw_build assembly:
 *     original: rx_buf[13] << 24  — uint8_t promoted to int, then shifted
 *                                    into the sign bit (UB in C).
 *     fixed:    explicit cast to uint32_t before shifting.
 *
 *  6. Boot drain loop made robust: reads until the queue is quiet for
 *     BNO_DRAIN_QUIET_COUNT consecutive empty polls.
 *
 *  7. All magic numbers replaced with named constants from the header.
 *
 *  8. Data grouped into a single local context struct inside read_packet()
 *     to keep related fields together and avoid multiple global variables.
 */

#include "bno08x.h"
#include <string.h>
#include <stdio.h>

/* ── Internal constants ──────────────────────────────────────────────────── */

#define SHTP_HEADER_LEN     ((uint8_t)4U)   /* length, channel, seq = 4 B  */

/*
 * TX buffer must hold the largest command we ever send:
 *   Set Feature Command = 4 (SHTP hdr) + 17 (SH2 payload) = 21 bytes.
 */
#define TX_BUF_SIZE         ((uint8_t)24U)

/*
 * Number of consecutive empty (no-payload) packets that indicate the
 * BNO08x transmit queue is drained.
 */
#define BNO_DRAIN_QUIET_COUNT  ((uint8_t)2U)

/* Maximum drain attempts before giving up */
#define BNO_DRAIN_MAX_ATTEMPTS ((uint8_t)30U)

/* Maximum attempts to find a Product ID response */
#define BNO_PID_MAX_ATTEMPTS   ((uint8_t)15U)

/* ── Module-level TX sequence counters ───────────────────────────────────── */

/*
 * One sequence number per SHTP channel (spec defines channels 0–5).
 * Wraps naturally at uint8_t overflow — correct per spec.
 */
static uint8_t s_tx_seq[SHTP_CH_MAX];

/* ── SHTP packet context (local to each read_packet call) ───────────────── */

/**
 * @brief  Aggregates all fields decoded from one SHTP packet.
 *
 * Grouping header metadata with the payload buffer avoids scattered locals
 * and makes the relationship between total_len, channel, and payload explicit.
 */
typedef struct {
    uint8_t  buf[BNO_RX_BUF_SIZE]; /**< Raw bytes (header + payload)       */
    uint16_t total_len;             /**< Declared packet length (from hdr)  */
    uint8_t  channel;               /**< SHTP channel ID                    */
    uint8_t  seq;                   /**< Received sequence number           */
} ShtpPacket_t;

/* ── Low-level SHTP I/O ──────────────────────────────────────────────────── */

/**
 * @brief  Read exactly one SHTP packet in a *single* I²C transaction.
 *
 * The BNO08x SHTP protocol over I²C works as follows:
 *   • The sensor keeps a packet queued.
 *   • A single Master_Receive() of N bytes reads the SHTP header (4 B) and
 *     the payload (N-4 B) atomically.  N must match or exceed the declared
 *     packet length from the header.
 *   • Requesting fewer bytes than the declared length truncates the packet
 *     but still consumes it from the queue (so a second call is safe and
 *     will return the *next* queued packet, not a retry of the same one).
 *
 * Strategy used here:
 *   1. Read up to BNO_RX_BUF_SIZE bytes in one transaction.
 *   2. Parse the length from the first two bytes.
 *   3. If the sensor declared more bytes than the buffer holds, we have
 *      already truncated; the packet is consumed.  Callers check total_len
 *      against their own record-size expectations.
 *
 * @param[out] pkt  Populated on HAL_OK.
 * @return HAL_OK or HAL_ERROR.
 */
static HAL_StatusTypeDef read_packet(ShtpPacket_t *pkt)
{
    memset(pkt->buf, 0, sizeof(pkt->buf));

    /*
     * Read header + as much payload as the buffer allows in one shot.
     * BNO08x will NAK if we try to read 0 bytes, so BNO_RX_BUF_SIZE ≥ 4
     * must hold (it is 64).
     */
    if (HAL_I2C_Master_Receive(&BNO_I2C, BNO_I2C_ADDR,
                                pkt->buf, BNO_RX_BUF_SIZE,
                                BNO_I2C_TIMEOUT_MS) != HAL_OK) {
        return HAL_ERROR;
    }

    /* Bytes [0..1]: packet length, bit-15 is continuation flag (mask it). */
    pkt->total_len = (uint16_t)(((uint16_t)pkt->buf[1] << 8) | pkt->buf[0])
                     & (uint16_t)0x7FFF;
    pkt->channel   = pkt->buf[2];
    pkt->seq       = pkt->buf[3];

    return HAL_OK;
}

/**
 * @brief  Write one SHTP packet.
 *
 * @param[in] channel  Destination SHTP channel.
 * @param[in] payload  SH2 payload bytes (without SHTP header).
 * @param[in] plen     Payload length in bytes.
 * @return HAL_OK or HAL_ERROR.
 */
static HAL_StatusTypeDef send_packet(uint8_t channel,
                                     const uint8_t *payload,
                                     uint8_t plen)
{
    uint8_t  tx[TX_BUF_SIZE];
    uint16_t total = (uint16_t)(SHTP_HEADER_LEN + plen);

    if (total > (uint16_t)sizeof(tx) || channel >= SHTP_CH_MAX) {
        return HAL_ERROR;
    }

    /* SHTP header */
    tx[0] = (uint8_t)(total & 0xFFU);
    tx[1] = (uint8_t)(total >> 8);
    tx[2] = channel;
    tx[3] = s_tx_seq[channel]++;   /* sequence wraps at 255→0 per spec */

    memcpy(&tx[SHTP_HEADER_LEN], payload, plen);

    return HAL_I2C_Master_Transmit(&BNO_I2C, BNO_I2C_ADDR,
                                   tx, (uint16_t)total,
                                   BNO_I2C_TIMEOUT_MS);
}

/**
 * @brief  Drain the BNO08x packet queue until quiet.
 *
 * Reads packets until BNO_DRAIN_QUIET_COUNT consecutive reads return a
 * zero-payload packet (total_len == 0 or total_len <= SHTP_HEADER_LEN),
 * or BNO_DRAIN_MAX_ATTEMPTS is exhausted.
 *
 * No HAL_Delay() inside — caller inserts delays if needed.
 */
static void drain_queue(void)
{
    ShtpPacket_t pkt;
    uint8_t      quiet   = 0;
    uint8_t      attempt = 0;

    while (attempt < BNO_DRAIN_MAX_ATTEMPTS && quiet < BNO_DRAIN_QUIET_COUNT) {
        if (read_packet(&pkt) != HAL_OK) {
            quiet++;             /* I²C error counts as empty */
        } else if (pkt.total_len <= SHTP_HEADER_LEN) {
            quiet++;
        } else {
            quiet = 0;           /* real packet — keep draining */
        }
        attempt++;
    }
}

/* ── Public API ──────────────────────────────────────────────────────────── */

void i2c_bus_scan(char *out, size_t bufsz)
{
    char    addr_str[8];
    uint8_t first = 1U;

    if (bufsz == 0U) return;
    out[0] = '\0';

    for (uint8_t addr = 1U; addr < 127U; addr++) {
        if (HAL_I2C_IsDeviceReady(&BNO_I2C,
                                  (uint16_t)(addr << 1),
                                  2U, 10U) == HAL_OK) {
            if (first == 0U) {
                strncat(out, ",", bufsz - strlen(out) - 1U);
            }
            /* snprintf is safe here; addr_str is long enough for "0xNN\0" */
            (void)snprintf(addr_str, sizeof(addr_str), "0x%02X", addr);
            strncat(out, addr_str, bufsz - strlen(out) - 1U);
            first = 0U;
        }
    }
}

/*
 * BNO08x_Init
 * ───────────
 * Timing budget (caller must insert delays between calls):
 *   Power-on → Init()         : sensor needs ~400 ms before I²C is ready.
 *   Init() → GetProductID()   : ≥ 10 ms after soft-reset settles.
 *
 * This function itself blocks only for the HAL I²C calls (~ms range).
 *
 *           ┌─ caller waits 500 ms ─┐
 *   POR     BNO08x_Init()   BNO08x_GetProductID()  BNO08x_EnableRotVec()
 *   ───────►──────────────►──────────────────────►──────────────────────►
 */
HAL_StatusTypeDef BNO08x_Init(void)
{
    memset(s_tx_seq, 0U, sizeof(s_tx_seq));

    /*
     * Step 1: consume the boot advertisement packet the BNO08x sends
     * immediately after power-on.  We tolerate a single read failure here
     * because on some boards the first I²C access can NAK if the sensor is
     * still asserting its own internal reset.
     */
    ShtpPacket_t pkt;
    (void)read_packet(&pkt);   /* return value intentionally ignored */

    /*
     * Step 2: soft reset — clears SH2 internal state without a hardware
     * reset pin.  Issued on the EXECUTABLE channel per the SH2 spec §6.4.1.
     */
    const uint8_t reset_cmd = EXEC_SOFT_RESET;
    if (send_packet(SHTP_CH_EXECUTABLE, &reset_cmd, 1U) != HAL_OK) {
        return HAL_ERROR;
    }

    /*
     * Caller is responsible for waiting ≥ 400 ms before the next call so
     * the sensor completes its post-reset boot sequence.
     */
    return HAL_OK;
}

HAL_StatusTypeDef BNO08x_GetProductID(BNO08x_ProductID_t *pid)
{
    ShtpPacket_t pkt;
    pid->valid = false;

    /* Flush any queued boot/advertisement packets. */
    drain_queue();

    /* Request product ID (SH2 ref §6.5.1). */
    const uint8_t cmd[2] = { SH2_GET_PRODUCT_ID, 0x00U };
    if (send_packet(SHTP_CH_CONTROL, cmd, (uint8_t)sizeof(cmd)) != HAL_OK) {
        return HAL_ERROR;
    }

    /* Poll for the response — typically arrives within 1–3 read cycles. */
    for (uint8_t attempt = 0U; attempt < BNO_PID_MAX_ATTEMPTS; attempt++) {

        if (read_packet(&pkt) != HAL_OK) {
            continue;
        }

        /* Ignore non-control-channel and non-matching report IDs. */
        if (pkt.channel != SHTP_CH_CONTROL) {
            continue;
        }

        /*
         * Control channel payload starts at buf[4].
         * Minimum packet size for a valid PID response:
         *   4 (hdr) + 16 (PID payload) = 20 bytes.
         */
        if (pkt.total_len < (uint16_t)20U) {
            continue;
        }

        if (pkt.buf[4] != SH2_PRODUCT_ID_RESP) {
            continue;
        }

        /*
         * Product ID response layout (SH2 ref §6.5.1.1, relative to buf[4]):
         *  [0]     0xF8  report ID
         *  [1]     reset cause
         *  [2]     sw_major
         *  [3]     sw_minor
         *  [4..7]  sw_build    (uint32, LE)
         *  [6..7]  sw_patch    (uint16, LE)  ← actually at offset [6..7]
         *  [8..9]  part number (uint16, LE)
         *
         * Note: offsets in the full buf[] are +4 (after SHTP header).
         *
         * Byte positions in pkt.buf:
         *   buf[4]  = report ID   (0xF8)
         *   buf[5]  = reset cause
         *   buf[6]  = sw_major
         *   buf[7]  = sw_minor
         *   buf[8..11]  = sw_build  (LE uint32)
         *   buf[12..13] = sw_patch  (LE uint16)
         *   buf[14..15] = part_num  (LE uint16)  [some firmwares, verify datasheet]
         *
         * IMPORTANT: cast uint8_t to uint32_t BEFORE shifting to avoid
         * signed-integer overflow UB (C11 §6.5.7¶4).
         */
        pid->sw_major    = pkt.buf[6];
        pid->sw_minor    = pkt.buf[7];
        pid->sw_build    = ((uint32_t)pkt.buf[11] << 24)
                         | ((uint32_t)pkt.buf[10] << 16)
                         | ((uint32_t)pkt.buf[ 9] <<  8)
                         |  (uint32_t)pkt.buf[ 8];
        pid->sw_patch    = ((uint16_t)pkt.buf[13] << 8)
                         |  (uint16_t)pkt.buf[12];
        pid->part_number = ((uint16_t)pkt.buf[15] << 8)
                         |  (uint16_t)pkt.buf[14];
        pid->valid       = true;

        return HAL_OK;
    }

    return HAL_ERROR;   /* response never arrived */
}

HAL_StatusTypeDef BNO08x_EnableRotVec(uint32_t interval_us)
{
    /*
     * Set Feature Command (SH2 ref §6.5.4), payload = 17 bytes:
     *  [0]      0xFD  Set Feature Command
     *  [1]      0x05  Rotation Vector report ID
     *  [2..3]   reserved (zero)
     *  [4..7]   report interval µs, little-endian uint32
     *  [8..11]  batch interval µs, LE uint32 (0 = immediate)
     *  [12..15] sensor-specific config (0 = default)
     *  [16]     reserved (zero)
     */
    uint8_t cmd[17];
    memset(cmd, 0, sizeof(cmd));

    cmd[0] = SH2_SET_FEATURE_CMD;
    cmd[1] = SH2_ROTATION_VECTOR;
    cmd[4] = (uint8_t)( interval_us        & 0xFFU);
    cmd[5] = (uint8_t)((interval_us >>  8) & 0xFFU);
    cmd[6] = (uint8_t)((interval_us >> 16) & 0xFFU);
    cmd[7] = (uint8_t)((interval_us >> 24) & 0xFFU);

    return send_packet(SHTP_CH_CONTROL, cmd, (uint8_t)sizeof(cmd));
    /* Caller must wait ≥ 50 ms before expecting first report. */
}

HAL_StatusTypeDef BNO08x_ReadPacket(BNO08x_RotVec_t *out)
{
    ShtpPacket_t pkt;
    out->valid = false;

    if (read_packet(&pkt) != HAL_OK) {
        return HAL_ERROR;
    }

    /* Only sensor report channel carries rotation vector data. */
    if (pkt.channel != SHTP_CH_REPORTS) {
        return HAL_OK;
    }

    /* Clamp total_len to buffer size to guard against oversized declarations. */
    uint16_t total = (pkt.total_len < BNO_RX_BUF_SIZE)
                     ? pkt.total_len : BNO_RX_BUF_SIZE;

    if (total < SHTP_HEADER_LEN) {
        return HAL_OK;
    }

    /*
     * Walk through payload sub-records starting after the SHTP header.
     *
     * Channel 3 payload layout (typical):
     *   [0xFB] Base Timestamp Ref  — SHTP_BASE_TS_LEN   (5 B) bytes
     *   [0xFC] Timestamp Rebase    — SHTP_TS_REBASE_LEN (4 B) bytes
     *   [0x05] Rotation Vector     — SHTP_ROT_VEC_LEN  (14 B) bytes  ← target
     *
     * Unknown record ID → bail out (can't determine size, would desync).
     */
    uint16_t offset = SHTP_HEADER_LEN;

    while (offset < total) {
        uint8_t rid = pkt.buf[offset];

        if (rid == SHTP_RID_BASE_TS) {
            offset += SHTP_BASE_TS_LEN;
            continue;
        }
        if (rid == SHTP_RID_TS_REBASE) {
            offset += SHTP_TS_REBASE_LEN;
            continue;
        }
        if (rid == SH2_ROTATION_VECTOR) {
            break;      /* found the rotation vector sub-record */
        }

        /* Unknown record — cannot safely advance; discard packet. */
        return HAL_OK;
    }

    /*
     * Bounds check:
     * The rotation vector record occupies bytes [offset … offset + 13].
     * We need offset + SHTP_ROT_VEC_LEN (== offset + 14) ≤ total,
     * i.e. the last byte index is offset + 13 < total.
     *
     * Original code used "> RX_BUF_SIZE" — insufficient; must check both
     * the buffer bound AND the declared packet length.
     */
    if ((uint32_t)offset + SHTP_ROT_VEC_LEN > (uint32_t)total) {
        return HAL_OK;   /* truncated packet */
    }

    if (pkt.buf[offset] != SH2_ROTATION_VECTOR) {
        return HAL_OK;
    }

    /*
     * Rotation vector sub-record layout (SH2 ref §6.5.18, relative to offset):
     *  [0]      report ID    (0x05)
     *  [1]      sequence no.
     *  [2]      status / accuracy (lower 2 bits = accuracy class)
     *  [3]      delay (ms, uint8)
     *  [4..5]   Q_i   (int16, Q14) — quaternion X
     *  [6..7]   Q_j   (int16, Q14) — quaternion Y
     *  [8..9]   Q_k   (int16, Q14) — quaternion Z
     *  [10..11] Q_real (int16, Q14) — quaternion W
     *  [12..13] accuracy estimate (int16, Q12, radians)
     *
     * Cast pattern: read two uint8_t, combine into uint16_t, then reinterpret
     * as int16_t — avoids aliasing UB and is well-defined in C11.
     */
#define READ_I16(buf, off) \
    ((int16_t)(((uint16_t)(buf)[(off)+1] << 8) | (uint16_t)(buf)[(off)]))

    int16_t qi  = READ_I16(pkt.buf, offset +  4);
    int16_t qj  = READ_I16(pkt.buf, offset +  6);
    int16_t qk  = READ_I16(pkt.buf, offset +  8);
    int16_t qr  = READ_I16(pkt.buf, offset + 10);
    int16_t acc = READ_I16(pkt.buf, offset + 12);

#undef READ_I16

    out->i            = (float)qi  * SCALE_Q14;
    out->j            = (float)qj  * SCALE_Q14;
    out->k            = (float)qk  * SCALE_Q14;
    out->real         = (float)qr  * SCALE_Q14;
    out->accuracy_rad = (float)acc * SCALE_Q12;
    out->valid        = true;

    return HAL_OK;
}
