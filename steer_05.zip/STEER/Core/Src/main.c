/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "math.h"
#include "stdio.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define WHEELBASE 2.264f
#define TRACK 1.45f
#define KMH_TO_MS (5.0f/18.0f)
#define PI 3.141592f
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
float err,diff,speed;
int steer, RcvData;
uint8_t RxData[8];
uint16_t speed_raw = 0;
char uartTxBuf[32];
CAN_RxHeaderTypeDef RxHeader;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static inline float MapFloat(float x, float in_min, float in_max, float out_min, float out_max);
static inline float ConstrainFloat(float value, float minVal, float maxVal);
static inline float cantoWheelangle(int x);
static inline float steerHead(float vel, float angle_in, float delta_t);
static inline float degtoRad(float deg);
static inline float radtoDeg(float rd);
static inline float headNormal(float err_val);
void serialWrite(char *uart2Data);
void can_Receive(void);
void can_Pidhead();
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim2);
  can_Receive();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  uint32_t last_time = HAL_GetTick();
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  can_Pidhead();
	  volatile uint32_t elapsed_time = HAL_GetTick() - last_time;
	    if (elapsed_time >= 10)
	    {
//	        sprintf(uartTxBuf, "%d\r\n", elapsed_time);
//	        HAL_UART_Transmit(&huart1, (uint8_t *)uartTxBuf, strlen(uartTxBuf), 10);
	    	sprintf(uartTxBuf, "%d\r\n", steer);
	    	HAL_UART_Transmit(&huart1, (uint8_t *)uartTxBuf, strlen(uartTxBuf), 10);
	        // Execute your 10ms task here
	        last_time = HAL_GetTick(); // Reset the anchor time
	    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN;
  hcan.Init.Prescaler = 8;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_7TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_8TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */

  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 63;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
static inline float MapFloat(float x, float in_min, float in_max, float out_min, float out_max){
    return ((x - in_min) * (out_max - out_min) / (in_max - in_min)) + out_min;
}

static inline float ConstrainFloat(float value, float minVal, float maxVal){
	if(value > maxVal) return maxVal;
	if(value < minVal) return minVal;
	return value;
}

static inline float cantoWheelangle(int x) {
	float ang = (0.0006f*x*x) + (0.3948f*x) - 48.4053f;
	return ang;
}

static inline float steerHead(float vel, float angle_in, float delta_t) {
	float tang = tan(degtoRad(angle_in));
	float rad = (WHEELBASE / tang) - TRACK / 2;
	float omega = vel / rad;
	float theta = radtoDeg((omega*delta_t));
	return theta;
}

static inline float degtoRad(float deg){
	return (deg * (PI / 180.0f));
}

static inline float radtoDeg(float rd){
	return (rd * (180.0f / PI));
}

static inline float headNormal(float err_val) {
	if(err_val < 0.0f && err_val > -360.0f) err_val = err_val + 360.0f;
	else if(err_val > 360.0f) err_val = err_val - 360.0f;
	return err_val;
}

void serialWrite(char *uart2Data) {
	HAL_StatusTypeDef uart_status;
	uart_status = HAL_UART_Transmit(&huart1, (uint8_t*) uart2Data, strlen(uart2Data), 10);
	if (uart_status != HAL_OK) {
		HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_3);
		HAL_Delay(100);
	}
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
	if(huart->Instance ==USART2) {
		if(huart->ErrorCode & HAL_UART_ERROR_ORE) {
			serialWrite("ORE\r\n");
			__HAL_UART_CLEAR_OREFLAG(huart);
		}
	}
}

void can_Receive(void) {
	RxHeader.IDE = CAN_ID_STD;
	RxHeader.DLC = 8;
	RxHeader.RTR = CAN_RTR_DATA;

	CAN_FilterTypeDef canfilterconfig;

	canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
	canfilterconfig.FilterBank = 1;
	canfilterconfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK;
	canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT;
	canfilterconfig.FilterIdHigh = 0x1fff;
	canfilterconfig.FilterIdLow = 0xffff;
	canfilterconfig.FilterMaskIdHigh = 0;
	canfilterconfig.FilterMaskIdLow = 0;

	if (HAL_CAN_ConfigFilter(&hcan, &canfilterconfig) != HAL_OK) {
		Error_Handler();
	}

	if (HAL_CAN_Start(&hcan) != HAL_OK) {
		Error_Handler();
	}
}

void can_Pidhead() {
	uint32_t start_ht;
	static uint32_t final_ht = 0;
	int head_k;
	static float integral_h = 0.0f, prev_errorh = 0.0f, setPoint_h = 0.0f;
	float head_h, kp_h = 200.0f, ki_h = 0.0000f, kd_h = 2.0f, elapsedTime_h, error_h, derivative_h, PID_valueh = 0.0f;

	while (HAL_CAN_GetRxFifoFillLevel(&hcan, CAN_RX_FIFO0) > 0) {
		if (HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK) {
			Error_Handler();
		}

		start_ht = HAL_GetTick();
		if (RxHeader.StdId == 0x691) {
			head_k = (RxData[0] | RxData[1] << 8);
			float velo = (float) speed_raw * 0.01f * KMH_TO_MS;
			speed = velo;
			float wng = cantoWheelangle(RcvData);
			float diff_ang = steerHead(velo,wng,1.0f);
			diff = diff_ang;
			head_h = (float) head_k * 0.01f;
			head_h = head_h - diff_ang;
			head_h = headNormal(head_h);
			error_h = setPoint_h - head_h;
			if (error_h > 180.0f) {
				error_h = error_h - 360.0f;
			}
			else if (error_h < -180.0f) {
				error_h = error_h + 360.0f;
			}
			err = error_h;
			elapsedTime_h = ((float) (start_ht - final_ht))/1000.0f;
			if(elapsedTime_h <= 0.000f) elapsedTime_h = 0.001f;
			integral_h += (error_h * elapsedTime_h);
			if(integral_h >= 10000.0f) integral_h = 10000.0f;
			if(integral_h <= -10000.0f) integral_h = -10000.0f;
			derivative_h = ((error_h - prev_errorh) / elapsedTime_h);
			PID_valueh = (kp_h * error_h + ki_h * integral_h + kd_h * derivative_h);
			prev_errorh = error_h;
			final_ht = start_ht;
			float dutyCycleh = ConstrainFloat(PID_valueh, -4095.0f, 4095.0f);
			float vah = MapFloat(dutyCycleh, -4095.0f, 4095.0f, 0.0f, 255.0f);
			steer = (2.59f * 0.0001f * vah * vah) - (0.643f * vah) + 184.0f;
		}

		if (RxHeader.StdId == 0x12) {
			RcvData = RxData[0];
		}

		if (RxHeader.StdId == 0x104) {
			speed_raw = ((RxData[0] << 8) | RxData[1]);
		}
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
